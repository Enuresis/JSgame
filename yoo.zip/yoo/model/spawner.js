export class Spawner {
    constructor({position}) {
        this.position = position;
    }
}